export enum UserRole {
    SuperAdmin = 'SuperAdmin',
    Admin = 'Admin',
    User = 'User',
    Ambassador = 'Ambassador'
}