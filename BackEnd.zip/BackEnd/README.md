## Description

[Nest](https://github.com/nestjs/nest) framework for the contact repository.

## Local Installation

```bash
$ npm install
```

## Running the app

```bash
# development
$ npm run start:dev

# Start API
$ npm start

```